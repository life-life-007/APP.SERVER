function addTr(){
	$('#copy').append($('#copyTr').clone());
}

function delTr(trs){
	$(trs).parents('tr:first').remove();
}

function send() {
	
	var url = $('#http_pre').val() + $('#pre_url').val();
	
	var data = {};
	
	var requestBody = {};
	$('#copy tr').each(function(i,item){
		var params = $('input[id="params"]',item).val();
		var values = $('input[id="values"]',item).val();
		requestBody[params] = values;
	});
	
	data['requestBody'] = JSON.stringify(requestBody);
	data['encodeKey'] = '1234';
	
	$.ajax({
				url : url,
				data : data,
				type : "POST",
				dataType : 'json',
				success : function(json) {
					var abc = JSON.stringify(json);
					var abc1 = JSON.parse(abc);
					var cde =  JsonUti.convertToString(abc1);  
					$('#showDiv').html(cde);
				},
				error : function(XMLHttpRequest, textStatus, errorThrown) {
					    //alert(XMLHttpRequest.status);
                        //alert(XMLHttpRequest.readyState);
                        alert(textStatus); // paser error;
				}
			});
}